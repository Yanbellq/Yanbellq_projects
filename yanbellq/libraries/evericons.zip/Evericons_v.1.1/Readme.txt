A B O U T


Evericons is a free icon pack designed by Aleksey Popov. 
Main icons are made on a 24×24 grid, and additional icons are made on 16×16 grid.


If you like to suggest a new icons, please use this form:
http://bit.ly/evericons


****************************

  
V E R S I O N

Version 1.1
from November 15, 2018


You can always download a fresh version on our site:
http://evericons.com



****************************


 
L I C E N S E


Evericons is licensed under the CC0 1.0 Universal (CC0 1.0).
That's mean you could use this pack like you want and no copyright needed.


Get more information here: 
https://creativecommons.org/publicdomain/zero/1.0/



****************************


  
D O N A T E  &  S U P P O R T


We make a great and free collection of icons. 
And only with your support, we are able to develop this project.

Please help us keep this work going.
SUPPORT EVERICONS


Become our Patron
https://patreon.com/evericons


Donate Ethereum
0xb765DaE0FbB76cFBECF9b1970B88b0DE81DD285A


Donate Bitcoin
12PBpYvuB8hNwgTNLmYJEhXRoKwspXt55D


Buy stuff
https://society6.com/alekseypopov


Share the Love
Please help us to spread information about Evericons. Write a post on your blog or just share a link on Twitter.



****************************

 
C O N T A C T S


http://evericons.com
evericons@gmail.com

Follow us on Twitter:
https://twitter.com/snocireve

____________________________


Aleksey Popov

http://alekseypopov.com/

https://dribbble.com/AlekseyPopov
https://twitter.com/AlekseyPopov


https://t.me/moodboardpicker


****************************











... don't forget to read a Bonus.txt




